import { Component, OnInit } from '@angular/core';
import { ClientService } from '../client.service';
@Component({
  selector: 'app-create-new-user',
  templateUrl: './create-new-user.component.html',
  styleUrls: ['./create-new-user.component.css']
})
export class CreateNewUserComponent implements OnInit {
  array: any
  accNum: number;
  successflag = false
  user: any
  constructor(private service: ClientService) { }

  ngOnInit() {
  }

  add(form) {

    this.user={
      name: form.name,
      phoneNumber: form.phone,
      emailId: form.email,
      balance: 0
    }
    this.service.create(this.user).subscribe(data=> {this.array=data})
    this.successflag = true;
  }
}
