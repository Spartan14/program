import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class AuthorDao {
	ResultSet rs;
	Author a;
	public int addEmployee(Author au)
	{	int row=0;
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root","root");
			Statement stmt=con.createStatement();
			row=stmt.executeUpdate("insert into author values ("+au.getAuthor_Id()+",'"+au.getFirstName()+"','"+au.getMiddleName()+"','"+au.getLastName()+"','"+au.getPhoneNo()+"');");
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return row;
	}
	public int updateEmployee(String s)
	{int row=0;
		try {
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root","root");
		Statement stmt=con.createStatement();
		row=stmt.executeUpdate("update author set phoneNo='"+s+"' where eid=1;");
		stmt.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
		
		return row ;
		
	}
	public void deleteEmployee()
	{
		try {
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root","root");
			Statement stmt=con.createStatement();
			stmt.executeUpdate("delete from author where eid=1;");
			stmt.close();
			System.out.println("DONE");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
@SuppressWarnings("hiding")
public  ArrayList<Author> display()
{	
	ArrayList <Author>list=new ArrayList<Author>();
	try {
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/employee","root","root");
		Statement stmt=con.createStatement();
		rs=stmt.executeQuery("Select * from author;");
		while(rs.next())
		{	a=new Author();
			a.setAuthor_Id(rs.getInt(1));
			a.setFirstName(rs.getString(2));
			a.setMiddleName(rs.getString(3));
			a.setLastName(rs.getString(4));
			a.setPhoneNo(rs.getString(5));
			list.add(a);
		}
		stmt.close();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	return list;
}
}
